/*
 * This application configures UART 16550 to baud rate 9600.
 * PS7 UART (Zynq) is not initialized by this application, since
 * bootrom/bsp configures it to baud rate 115200
 *
 * ------------------------------------------------
 * | UART TYPE   BAUD RATE                        |
 * ------------------------------------------------
 *   uartns550   9600
 *   uartlite    Configurable only in HW design
 *   ps7_uart    115200 (configured by bootrom/bsp)
 */

#include <stdio.h>
#include "platform.h"

#include "xil_printf.h"
#include "xparameters.h"
#include "xgpio.h"

#include "xscugic.h"
#include "xil_exception.h"

// Get device IDs from xparameters.h
#define INTC_ID                XPAR_PS7_SCUGIC_0_DEVICE_ID
#define BTN_ID                 XPAR_AXI_GPIO_BUTTONS_DEVICE_ID
#define LED_ID                 XPAR_AXI_GPIO_LEDS_DEVICE_ID
#define INTC_GPIO_INTERRUPT_ID XPAR_FABRIC_AXI_GPIO_BUTTONS_IP2INTC_IRPT_INTR

#define BTN_CHANNEL  1
#define LED_CHANNEL  1
#define BTN_MASK     0b1111
#define BTN_INT XGPIO_IR_CH1_MASK

XGpio led_device, btn_device;
XGpio_Config *cfg_ptr;

static int led_data;
static int btn_value;

XScuGic InterruptController;
static XScuGic_Config *GicConfig;

void ExtIrq_Handler()
{
    xil_printf("ExtIrq_Handler\r\n");

    // Disable GPIO interrupts
    XGpio_InterruptDisable(&btn_device, BTN_INT);
    // Ignore additional button presses
    if ((XGpio_InterruptGetStatus(&btn_device) & BTN_INT) != BTN_INT) {
        return;
    }

    btn_value = XGpio_DiscreteRead(&btn_device, 1);
    // led on based on button value
    if (btn_value != 0)
        led_data = btn_value;
    else
        led_data = 0;

    XGpio_DiscreteWrite(&led_device, 1, led_data);
    (void) XGpio_InterruptClear(&btn_device, BTN_INT);

    // Enable GPIO interrupts
    XGpio_InterruptEnable(&btn_device, BTN_INT);
}

int SetUpInterruptSystem(XScuGic *XScuGicInstancePtr)
{
    // Enable interrupt
    XGpio_InterruptEnable(&btn_device, BTN_INT);
    XGpio_InterruptGlobalEnable(&btn_device);

    Xil_ExceptionRegisterHandler(XIL_EXCEPTION_ID_INT,
        (Xil_ExceptionHandler) XScuGic_InterruptHandler,
        XScuGicInstancePtr);
    Xil_ExceptionEnable();

    return XST_SUCCESS;
}

int interrupt_init()
{
    int Status;

    GicConfig = XScuGic_LookupConfig(XPAR_PS7_SCUGIC_0_DEVICE_ID);
    if (NULL == GicConfig)
        return XST_FAILURE;

    Status = XScuGic_CfgInitialize(&InterruptController, GicConfig, GicConfig->CpuBaseAddress);
    if (Status != XST_SUCCESS)
        return XST_FAILURE;

    Status = SetUpInterruptSystem(&InterruptController);
    if (Status != XST_SUCCESS)
        return XST_FAILURE;

    Status = XScuGic_Connect(&InterruptController, INTC_GPIO_INTERRUPT_ID, (Xil_ExceptionHandler)ExtIrq_Handler, (void *)&btn_device);
    if (Status != XST_SUCCESS)
        return XST_FAILURE;

    // Enable GPIO interrupts interrupt
    XGpio_InterruptEnable(&btn_device, 1);
    XGpio_InterruptGlobalEnable(&btn_device);

    XScuGic_Enable(&InterruptController, INTC_GPIO_INTERRUPT_ID);

    return XST_SUCCESS;
}

int main()
{
    int status;
    init_platform();

    xil_printf("Entered function main\r\n");

    // Initialize LED Device
    cfg_ptr = XGpio_LookupConfig(LED_ID);
    status = XGpio_CfgInitialize(&led_device, cfg_ptr, cfg_ptr->BaseAddress);
    if (status != XST_SUCCESS)
        return XST_FAILURE;

    // Initialize Button Device
    cfg_ptr = XGpio_LookupConfig(BTN_ID);
    status = XGpio_CfgInitialize(&btn_device, cfg_ptr, cfg_ptr->BaseAddress);
    if (status != XST_SUCCESS)
        return XST_FAILURE;

    // Set Led Tristate
    XGpio_SetDataDirection(&led_device, LED_CHANNEL, 0);

    // Set Button Tristate
    XGpio_SetDataDirection(&btn_device, BTN_CHANNEL, BTN_MASK);

    status = interrupt_init();
    if (status != XST_SUCCESS)
        return XST_FAILURE;

    while(1);

    cleanup_platform();
    return 0;
}
